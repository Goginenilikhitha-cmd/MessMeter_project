const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const User = require('../models/User');
const MealSelection = require('../models/MealSelection');
const WasteRecord = require('../models/WasteRecord');
const Rating = require('../models/Rating');
const { MEALS, isCutoffPassed, calculateHeadcount } = require('../utils/mealRules');
router.use(authenticate);
router.get('/me', (req, res) => res.json({ user: { id: req.user._id, name: req.user.name, email: req.user.email, role: req.user.role, studentId: req.user.studentId } }));
router.post('/meals', requireRole('student'), async (req, res, next) => {
  try {
    const { meals, serviceAt } = req.body;
    if (!Array.isArray(meals) || meals.some(m => !MEALS.includes(m)) || !serviceAt || Number.isNaN(new Date(serviceAt).getTime())) return res.status(400).json({ message: 'Provide a valid service date and meal selection.' });
    const cutoff = Number(process.env.MEAL_CUTOFF_HOURS || 6);
    if (isCutoffPassed(serviceAt, new Date(), cutoff)) return res.status(409).json({ message: `Meal selection is closed. Changes must be made at least ${cutoff} hours before the meal service.` });
    const selection = await MealSelection.findOneAndUpdate({ student: req.user._id, serviceAt: new Date(serviceAt) }, { meals }, { upsert: true, new: true, runValidators: true });
    res.status(201).json({ message: 'Meal selection saved on the server.', selection });
  } catch (e) { next(e); }
});
router.get('/meals/headcount', requireRole('admin'), async (req, res, next) => {
  try {
    const { serviceAt, meal } = req.query;
    if (!serviceAt || !MEALS.includes(meal)) return res.status(400).json({ message: 'serviceAt and a valid meal are required.' });
    const totalStudents = await User.countDocuments({ role: 'student' });
    const selections = await MealSelection.find({ serviceAt: new Date(serviceAt) }).select('meals');
    const optedOutCount = selections.filter(s => !s.meals.includes(meal)).length + Math.max(0, totalStudents - selections.length);
    res.json({ totalStudents, responses: selections.length, optedOutCount, expectedHeadcount: calculateHeadcount(totalStudents, optedOutCount), meal, serviceAt });
  } catch (e) { next(e); }
});
router.post('/waste', requireRole('admin'), async (req, res, next) => {
  try {
    const { date, kg, note = '' } = req.body;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '') || typeof kg !== 'number' || !Number.isFinite(kg) || kg < 0 || kg > 100000) return res.status(400).json({ message: 'Enter a valid date and waste amount in kilograms.' });
    const record = await WasteRecord.create({ date, kg, note, recordedBy: req.user._id });
    res.status(201).json({ message: 'Waste record saved.', record });
  } catch (e) { next(e); }
});
router.post('/ratings', requireRole('student'), async (req, res, next) => {
  try {
    const { dish, rating, feedback = '' } = req.body;
    if (typeof dish !== 'string' || !dish.trim() || dish.length > 100 || !Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ message: 'Enter a dish name and a whole-number rating from 1 to 5.' });
    const record = await Rating.create({ student: req.user._id, dish: dish.trim(), rating, feedback });
    res.status(201).json({ message: 'Thank you. Your rating has been saved.', record });
  } catch (e) { next(e); }
});
router.get('/dashboard', requireRole('admin'), async (req, res, next) => {
  try {
    const [waste, ratings, meals, students] = await Promise.all([WasteRecord.find().sort({ date: -1 }).limit(100), Rating.find(), MealSelection.find(), User.countDocuments({ role: 'student' })]);
    const totalWaste = waste.reduce((sum, r) => sum + r.kg, 0);
    const averageRating = ratings.length ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length : null;
    const grouped = {};
    ratings.forEach(r => { const key = r.dish; grouped[key] ||= { dish: key, total: 0, count: 0 }; grouped[key].total += r.rating; grouped[key].count++; });
    const dishRatings = Object.values(grouped).map(x => ({ dish: x.dish, average: x.total / x.count, count: x.count })).sort((a,b) => b.average - a.average);
    res.json({ totalStudents: students, totalWaste, averageRating, mealResponses: meals.length, waste, dishRatings, optedInMeals: meals.reduce((sum,m) => sum + m.meals.length, 0) });
  } catch (e) { next(e); }
});
module.exports = router;
