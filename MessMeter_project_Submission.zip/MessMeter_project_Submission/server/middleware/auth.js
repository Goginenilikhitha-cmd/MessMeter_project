const jwt = require('jsonwebtoken');
const User = require('../models/User');
async function authenticate(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) return res.status(401).json({ message: 'Please log in to continue.' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub).select('-passwordHash');
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });
    req.user = user; next();
  } catch { return res.status(401).json({ message: 'Your session is invalid or expired. Please log in again.' }); }
}
function requireRole(...roles) { return (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'You do not have permission to perform this action.' }); }
module.exports = { authenticate, requireRole };
